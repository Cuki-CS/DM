# Deployment Flow

## Normal flow

1. Developer opens PR to `dev`
2. GitHub Actions validates against DEV
3. Merge to `dev`
4. Pipeline deploys to DEV
5. Merge `dev` to `uat`
6. Pipeline validates and deploys to UAT
7. Team validates integrations in UAT
8. Merge `uat` to `master`
9. Pipeline validates production deployment
10. Approver approves deployment in GitHub Environment
11. Pipeline quick deploys to PROD

## Hotfix flow

1. Production issue identified
2. Create `hotfix/<ticket>` from `master`
3. Push hotfix branch
4. Pipeline validates and deploys hotfix to UAT
5. Confirm integrations in UAT
6. Merge hotfix to `master`
7. Pipeline validates for production
8. Approver approves deployment
9. Pipeline quick deploys to PROD
10. Back-merge hotfix into `dev`

## Delta deployment mode

When `USE_DELTA_DEPLOY=true`, workflows generate a manifest and destructive changes from Git differences and deploy only changed metadata.

## Full deployment mode

When `USE_DELTA_DEPLOY` is not set to `true`, workflows deploy from `force-app`.

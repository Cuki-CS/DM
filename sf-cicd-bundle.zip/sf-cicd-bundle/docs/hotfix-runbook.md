# Hotfix Runbook

## Purpose

Use this runbook for urgent production issues.

## Rules

- Hotfix branch must be created from `master`
- Hotfix must go to UAT first
- Integrations must be validated in UAT
- Production deployment happens only after approval
- Hotfix must be back-merged to `dev`

## Steps

### 1. Create branch

Create a branch from `master`:

```bash
git checkout master
git pull origin master
git checkout -b hotfix/INC-1234
```

### 2. Implement fix

Make the required metadata change and commit it.

### 3. Push hotfix branch

```bash
git push origin hotfix/INC-1234
```

This triggers the UAT validation and deployment workflow.

### 4. Validate in UAT

Confirm:
- bug is fixed
- impacted integrations work
- no regression found

### 5. Merge to master

Create a PR from `hotfix/INC-1234` into `master`.

### 6. Approve production deployment

Approve the `prod` environment deployment when the workflow pauses for review.

### 7. Confirm in production

Perform smoke tests.

### 8. Back-merge to dev

```bash
git checkout dev
git pull origin dev
git merge origin/master
git push origin dev
```

Or use a PR from `master` back to `dev`.

## Checklist

- [ ] Hotfix branched from `master`
- [ ] UAT deployed
- [ ] Integration testing completed
- [ ] PR merged to `master`
- [ ] PROD approved
- [ ] PROD smoke test passed
- [ ] Back-merge to `dev` completed

#!/usr/bin/env bash
set -euo pipefail

npm install --global @salesforce/cli
sf --version

npm install --global sfdx-git-delta
sf plugins

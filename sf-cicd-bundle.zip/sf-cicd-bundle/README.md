# Salesforce CI/CD with GitHub Actions

This repository implements a Salesforce deployment pipeline with these environments:

- `dev`
- `uat`
- `prod` via `master`

It also supports a hotfix path:

- `master` -> `hotfix/*` -> `uat` -> `master` -> `prod` -> back-merge to `dev`

## Branch strategy

- `feature/*` -> feature work
- `dev` -> integration branch
- `uat` -> release candidate branch
- `master` -> production branch
- `hotfix/*` -> urgent production fixes created from `master`

## Flow

### Normal release

1. Open PR into `dev`
2. Validate against DEV
3. Merge to `dev`
4. Deploy to DEV
5. Merge `dev` to `uat`
6. Validate and deploy to UAT
7. Test integrations and get signoff
8. Merge `uat` to `master`
9. Validate production deployment
10. Approve production deployment
11. Quick deploy to PROD

### Hotfix

1. Create `hotfix/<ticket>` from `master`
2. Validate and deploy hotfix to UAT
3. Confirm integrations in UAT
4. Merge hotfix to `master`
5. Validate and quick deploy to PROD
6. Back-merge hotfix into `dev`

## GitHub environments

Create these GitHub environments:

- `dev`
- `uat`
- `prod`

Recommended:
- `uat`: optional reviewer gate
- `prod`: required reviewer gate

## Required secrets per environment

Add these secrets to each GitHub environment:

- `SF_USERNAME`
- `SF_CLIENT_ID`
- `SF_JWT_KEY`
- `SF_INSTANCE_URL`

Typical values:
- Sandbox/UAT instance URL: `https://test.salesforce.com`
- Production instance URL: `https://login.salesforce.com`

## Delta deployment support

This repo supports two deployment modes:

- full source deployment from `force-app`
- delta deployment using Git differences via `sfdx-git-delta`

To use delta mode, set this repository variable:

- `USE_DELTA_DEPLOY=true`

If not set, workflows deploy from `force-app`.

## Mermaid diagram

```mermaid
flowchart LR

subgraph Git["Git Branches"]
A[feature/*] --> B[dev]
B --> C[uat]
C --> D[master]
end

subgraph CI["GitHub Actions"]
E[Validate PR]
F[Deploy DEV]
G[Deploy UAT]
H[Validate PROD]
I[Deploy PROD]
end

subgraph SF["Salesforce Environments"]
J[DEV Org]
K[UAT Org - Integration Testing]
L[PROD Org]
end

B --> E
E --> F
F --> J
J --> G
G --> K
K --> H
H --> I
I --> L

D --> M[hotfix/*]
M --> G
I --> N[Back-merge to dev]
N --> B
```

## Notes

- UAT is the integration validation gate.
- Production deployments use validate + quick deploy.
- UAT uses standard validation and deployment, not quick deploy.
- Hotfixes do not go directly to production.

## Optional repository variables

Set these in GitHub Actions Variables if needed:

- `USE_DELTA_DEPLOY=true`
- `DEPLOY_PATH=force-app`

## Branch protection

Recommended protection rules:

- `dev`: require PR and successful validation
- `uat`: require PR and successful UAT validation
- `master`: require PR, required reviewers, and successful production validation
